from flask import Flask , session , request , send_from_directory
import os
import time

stim = time.localtime()
ttim = time.localtime()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)

def gaohead():
	return '<div align="center">\
		welcome ' + session.get('usn') + "<br><br>\
		<a href='/'>home-page<a><br>\
		<a href='/yourlast'>check-your-last-submit</a><br>\
		<a href='/stan'>standing</a><br>\
		<br><br>"
		
def gaotail():
	return '<br><br><br>' + time.strftime("%H : %M : %S",time.localtime()) + '</div>'

def notbegin():
	global stim
	return time.localtime() < stim

def notbeginstring():
	global stimh; global stimm; global stims
	return gaohead() + '<h2>too early</h2>'\
			+'will start at    ' + time.strftime("%H : %M : %S",stim) + gaotail()

def howlong(t1,t2):
	return int(time.mktime(t2)) - int(time.mktime(t1))

def isac(uid,pid):
	if os.path.isfile('usr/' + uid + '/__' + pid):
		return 0
	else:
		return -1

def trytimes(uid,pid):
	if os.path.isfile('usr/' + uid + '/___' + pid):
		f = open('usr/' + uid + '/___' + pid)
		return int(f.read())
	else:
		return 0
	
def isokac(uid,pid):
	if os.path.isfile('usr/' + uid + '/__' + pid):
		f = open('usr/' + uid + '/__' + pid,'r')
		t = f.read().split('\n')
		oktim = time.strptime(t[0],'%Y-%m-%d-%H-%M-%S')
		if oktim <= ttim:
			return howlong(stim,oktim)//60
		else:
			return -1
	else:
		return -1

@app.route('/')
def face():
	if str(type(session.get('usn'))) == "<class 'NoneType'>":
		return \
			'<div align="center">\
				<form action="/login" method="POST">\
					username <input type="text" name="usnm"><br>\
					password <input type="password" name="pswd"><br>\
					<button>submit</button>\
				</form>\
				if you enter a new username<br>\
				then this operation will be seen as register<br>\
				attention it!<br>\
			</div>'
	else:
		if notbegin():
			return notbeginstring()
		res = ''
		if 1:
			f = open('prolist','r')
			t = f.read().split('\n')
			for s in t:
				if len(s) > 0:
					if isac(session['usn'],s) != -1:
						res = res + '<font color="00A000">' + s + '</font>'
					else:
						res = res + '<font color="A00000">' + s + '</font>'
					res = res + '&nbsp;&nbsp;&nbsp; <a href = "/sbmt/' + s + '">submit</a>'
					res = res + '&nbsp;&nbsp;&nbsp; <a href = "/ylof/' + s + '">last_sub</a>'
					res = res + '<br>'
		return gaohead() + res + gaotail()
		
	
@app.route('/login',methods=["POST"])
def login():
	A = request.form.get('usnm')
	SB = request.form.get('pswd')
	hs = 2333
	mod = int('1000000000000000009')
	for char in SB:
		hs = (hs * 998244353 + ord(char)) % mod
	B = str(hs)
	
	if os.path.isfile('usr/' + A):
		print(A + " is comming")
	else:
		print(A + " is registing")
		os.system('mkdir usr/' + A)
		f = open('usr/' + A + '/pswd','w')
		f.write(B)
	f = open('usr/' + A + '/pswd','r')
	t = f.read().split('\n')
	print(t[0])
	if t[0] == B:
		session['usn'] = A
	return '\
		<script type="text/javascript">\
			function Gogogo(){\
				window.location.href="/";\
			}\
			window.onload=Gogogo();\
		</script>'

@app.route('/sbmt/<pid>')
def sbmt(pid):
	if notbegin():
		return notbeginstring()
	return gaohead() +\
		'<form action="/submit" method="POST">\
			<input type="text" name="pid" value="' + pid + '"><br>\
			<textarea name="code" rows="10" cols="80"></textarea><br>\
			<button>submit</button>\
		</form>' + gaotail()

@app.route('/submit',methods=['POST'])
def submit():
	rq = request
	tot = 0
	deb=0
	
	if 1:
		f = open("sub/cnt","r")
		t = f.read().split('\n')
		tot = int(t[0])
		f.close()
	tot += 1
	if 1:
		f = open("sub/cnt","w")
		f.write(str(tot))
		f.close()
	
	print(tot,session['usn'],rq.form.get('code'),rq.form.get('pid'))
	os.system("mkdir sub/" + str(tot))
	deb+=1; print(deb);
	if 1:
		f = open("sub/" + str(tot) + "/bel","w")
		f.write(session['usn'])
	deb+=1; print(deb);
	if 1:
		f = open("sub/" + str(tot) + "/x.cpp","w")
		f.write(rq.form.get('code'))
	deb+=1; print(deb);
	if 1:
		f = open("sub/" + str(tot) + "/pid","w")
		f.write(rq.form.get('pid'))
	deb+=1; print(deb);
	if 1:
		f = open("sub/" + str(tot) + "/ans","w")
		f.write('<h1>pending</h1>')
	deb+=1; print(deb);
	if 1:
		f = open("sub/" + str(tot) + "/tim","w")
		f.write(time.strftime("%Y-%m-%d-%H-%M-%S",time.localtime()))
	deb+=1; print(deb);
	if 1:
		f = open("sub/todo/" + str(tot),"w")
		f.write('this file is empty')
	deb+=1; print(deb);
	if 1:
		f = open("usr/" + session['usn'] +"/alllast","w")
		f.write(str(tot))
	deb+=1; print(deb);
	if 1:
		f = open("usr/" + session['usn'] + "/_" + rq.form.get('pid'),"w")
		f.write(str(tot))
	deb+=1; print(deb);
	
	res = gaohead()
	return res + '<h3>submit complete</h3>' + gaotail()

@app.route('/rslt/<sid>')
def rslt(sid):
	if 1:
		f = open("sub/" + sid + "/bel","r")
		t = f.read().split('\n')
		if session['usn'] != t[0]:
			return "<h1>it's not your submit, what's your problem?</h1>"
	res = gaohead()
	f = open("sub/" + sid + "/ans","r")
	res = res + f.read() + '<br>'
	res = res + "<a href='/codes/" + sid + "'><h3>download-code</h3></a>"
	return res

@app.route("/codes/<sid>")
def codes(sid):
	if 1:
		f = open("sub/" + sid + "/bel","r")
		t = f.read().split('\n')
		if session['usn'] != t[0]:
			return "<h1>it's not your submit, what's your problem?</h1>"
	return send_from_directory("","sub/" + sid + "/x.cpp",as_attachment=True)

@app.route('/yourlast')
def ylst():
	A = session['usn']
	if os.path.isfile('usr/' + A + '/alllast'):
		print(A + ' is checking his submit')
	else:
		return "you don't have any submits. what's your problem?"
	sid = ''
	f = open('usr/' + A + '/alllast','r')
	t = f.read().split('\n')
	sid = t[0]
	return '\
		<script type="text/javascript">\
			function Gogogo(){\
				window.location.href="/rslt/' + sid + '";\
			}\
			window.onload=Gogogo();\
		</script>'

@app.route('/ylof/<pid>')
def ylof(pid):
	A = session['usn']
	if os.path.isfile('usr/' + A + '/_' + pid):
		print(A + ' is checking his submit of ' + pid)
	else:
		return "you don't have any submits of this problem. what's your problem?"
	sid = ''
	f = open('usr/' + A + '/_' + pid,'r')
	t = f.read().split('\n')
	sid = t[0]
	return '\
		<script type="text/javascript">\
			function Gogogo(){\
				window.location.href="/rslt/' + sid + '";\
			}\
			window.onload=Gogogo();\
		</script>'

@app.route('/stan')
def stan():
	uf = open('usrlist','r')
	u = uf.read().split('\n')
	u.pop(-1)
	pf = open('prolist','r')
	p = pf.read().split('\n')
	p.pop(-1)
	
	a = []
	for uid in u:
		b = [uid , 0 , 0]
		for pid in p:
			tim = isokac(uid,pid)
			c = trytimes(uid,pid)
			if tim != -1:
				b[1] += 1
				b[2] += tim + c*20
				b.append('+' + str(c) + '<br>' + str(tim))
			else:
				if c:
					b.append('-' + str(c) + '<br>' + '---')
				else:
					b.append(' <br> ')
		a.append(b)
	
	for sb in range(0,len(a)):
		for i in range(0,len(a)-1):
			if (a[i][1] < a[i+1][1]) | ( (a[i][1] == a[i+1][1]) & (a[i][2] > a[i+1][2]) ):
				a[i],a[i+1] = a[i+1],a[i]
	
	res = '<table align="center" cellpadding="15">\
				<tr>\
					<th></th>\
					<th>name</th>\
					<th>solved</th>\
					<th>time</th>'
	for pid in p:
		res = res + '<th>' + pid + '</th>'
	res = res + '</tr>'
	
	nowrank = 0
	
	for b in a:
		nowrank += 1
		res = res + '<tr>' + '<td>' + str(nowrank) + '</td>'
		for c in b:
			res = res + '<td>' + str(c) + '</td>'
		res = res + '</tr>'
	
	res = res + '</table>'
	
	return gaohead() + res + gaotail()

if __name__=='__main__':
	if 1:
		f = open("start_time_and_finish_time","r")
		t = f.read().split('\n')
		stim = time.strptime(t[0],'%Y-%m-%d-%H-%M-%S')
		ttim = time.strptime(t[1],'%Y-%m-%d-%H-%M-%S')
	
	app.run(host='0.0.0.0',port=5000)





