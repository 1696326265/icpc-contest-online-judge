import os

while 1:
	os.system("sleep 3")
	os.system("ls pro >prolist")
	print("problem set refreshed")
	os.system("sleep 3")
	os.system("ls usr >usrlist")
	print("user set refreshed")
	
