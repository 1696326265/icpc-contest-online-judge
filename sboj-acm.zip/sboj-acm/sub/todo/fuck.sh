ulimit -t 3
./x<../../pro/a/in>out