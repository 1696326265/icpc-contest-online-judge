#include<bits/stdc++.h>
#include<sys/time.h>
using namespace std;

long long gettime(){
	timeval tv;
	gettimeofday(&tv,NULL);
	long long x = tv.tv_sec*1000000ll + tv.tv_usec;
}

bool isfile(char s[]){
	FILE *f=fopen(s,"r");
	if (f==NULL) return 0;
	fclose(f);
	return 1;
}

char s[2333], str[2333], pid[2333], usn[2333];
double tl;

int main(){
	while (1){
		system("sleep 1");
		system("ls>files");
		{
			FILE *fs=fopen("files","r");
			while (fscanf(fs,"%s",s)!=-1){
				int l=strlen(s);
				if (isdigit(s[0])){
					cerr<<"doit "<<s<<endl;
					{
						sprintf(str,"../%s/pid",s);
						FILE *f=fopen(str,"r");
						fscanf(f,"%s",pid);
						fclose(f);
					}
					{
						sprintf(str,"../%s/bel",s);
						FILE *f=fopen(str,"r");
						fscanf(f,"%s",usn);
						fclose(f);
					}
					{
						sprintf(str,"../../pro/%s/tl",pid);
						FILE *f=fopen(str,"r");
						if (f==NULL){
							tl=1;
						}else{
							fscanf(f,"%lf",&tl);
							fclose(f);
						}
					}
					long long stim, ttim, mxtim=0; bool die=0;
						system("rm x");
						sprintf(str,"g++ ../%s/x.cpp -o x -O2",s);
						system(str);
					{
						sprintf(str,"../../pro/%s/datalist",pid);
						FILE *lst=fopen(str,"r");
						if (lst==NULL){
							cerr<<"null"<<endl;
							system("rm out");
							{
								FILE *sh=fopen("fuck.sh","w");
								fprintf(sh,"ulimit -t %.0lf\n",tl+2);
								fprintf(sh,"./x<../../pro/%s/in>out",pid);
								fclose(sh);
								stim=gettime(); system("bash fuck.sh"); ttim=gettime();
							}
							mxtim=ttim-stim;
							sprintf(str,"diff -b out ../../pro/%s/ans",pid);
							die= (mxtim/1e6>tl||system(str));
						}else{
							static char name[233];
							for (;fscanf(lst,"%s",name)!=-1&&!die;){
								system("rm out");
								{
									FILE *sh=fopen("fuck.sh","w");
									fprintf(sh,"ulimit -t %.0lf\n",tl+2);
									fprintf(sh,"./x<../../pro/%s/%s.in>out",pid,name);
									fclose(sh);
									stim=gettime(); system("bash fuck.sh"); ttim=gettime();
								}
								mxtim=max(mxtim,ttim-stim);
								sprintf(str,"diff -b out ../../pro/%s/%s.ans",pid,name);
								die|= (mxtim/1e6>tl||system(str));
							}
							fclose(lst);
						}
					}
					printf(" %s %s %s %lf\n",s,pid,usn,tl);
					{
						sprintf(str,"../%s/ans",s);
						FILE *ans=fopen(str,"w");
						//sprintf(str,"diff -b out ../../pro/%s/ans",pid);
						//if ((ttim-stim)/1e6>tl||system(str)){
						if (die){
							fprintf(ans,"<h2>Rejected</h2>\n");
							fprintf(ans,"<h3>timeusd : %lf</h3>\n",mxtim/1e6);
							fprintf(ans,"<h3>the code is from %s</h3>\n",usn);
							{
								sprintf(str,"../../usr/%s/__%s",usn,pid);
								if (!isfile(str)){
									sprintf(str,"../../usr/%s/___%s",usn,pid);
									int ttt=0;
									if (isfile(str)){
										FILE *f=fopen(str,"r");
										fscanf(f,"%d",&ttt);
										fclose(f);
									}
									{
										FILE *f=fopen(str,"w");
										fprintf(f,"%d",ttt+1);
										fclose(f);
									}
								}
							}
						}else{
							fprintf(ans,"<h2>Accepted</h2>\n");
							fprintf(ans,"<h3>timeusd : %lf</h3>\n",mxtim/1e6);
							fprintf(ans,"<h3>the code is from %s</h3>\n",usn);
							{
								sprintf(str,"../../usr/%s/__%s",usn,pid);
								if (!isfile(str)){
									sprintf(str,"cp ../%s/tim ../../usr/%s/__%s",s,usn,pid);
									system(str);
								}
							}
						}
						fclose(ans);
					}
					
					cerr<<" finish "<<s<<endl;
					sprintf(str,"rm %s",s);
					system(str);
					
					break;
				}
			}
			fclose(fs);
		}
	}
}





