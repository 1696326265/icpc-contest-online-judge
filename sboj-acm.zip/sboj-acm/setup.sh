cd sub/todo
g++ gao.cpp -o gao
./gao &
cd ../..
python3 refresher.py &
python3 main.py
